1、通过demo程序完成投屏显示：
    gcc fb_demo.c -o demo
    sudo ./demo -d 1 -l 100 -s 1280x720

   如果模块的输出接口是cvbs，-s后的参数改为cvbs输出对应的分辨率，比如：
    sudo ./demo -d 1 -l 100 -s 720x480

    参数说明：
    -d 驱动创建的fbdev设备: ’1‘表示"/dev/fb1"，执行前通过"ls /dev/fb*"枚举fbdev设备确认
    -l 循环次数
    -s 输出分辨率
